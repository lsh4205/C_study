/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=270x187 background background.png 
 * Time-stamp: Friday 04/03/2020, 10:34:02
 * 
 * Image Information
 * -----------------
 * background.png 270@187
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BACKGROUND_H
#define BACKGROUND_H

extern const unsigned short background[50490];
#define BACKGROUND_SIZE 100980
#define BACKGROUND_LENGTH 50490
#define BACKGROUND_WIDTH 270
#define BACKGROUND_HEIGHT 187

#endif


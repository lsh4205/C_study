/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=245x135 win win.jpg 
 * Time-stamp: Saturday 04/04/2020, 03:36:32
 * 
 * Image Information
 * -----------------
 * win.jpg 245@135
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WIN_H
#define WIN_H

extern const unsigned short win[33075];
#define WIN_SIZE 66150
#define WIN_LENGTH 33075
#define WIN_WIDTH 245
#define WIN_HEIGHT 135

#endif


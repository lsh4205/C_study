/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=200x200 gatech gatech.png 
 * Time-stamp: Friday 04/03/2020, 09:26:03
 * 
 * Image Information
 * -----------------
 * gatech.png 200@200
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef GATECH_H
#define GATECH_H

extern const unsigned short gatech[40000];
#define GATECH_SIZE 80000
#define GATECH_LENGTH 40000
#define GATECH_WIDTH 200
#define GATECH_HEIGHT 200

#endif


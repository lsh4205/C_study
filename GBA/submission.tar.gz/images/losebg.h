/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=200x160 losebg losebg.jpg 
 * Time-stamp: Saturday 04/04/2020, 03:45:46
 * 
 * Image Information
 * -----------------
 * losebg.jpg 200@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef LOSEBG_H
#define LOSEBG_H

extern const unsigned short losebg[32000];
#define LOSEBG_SIZE 64000
#define LOSEBG_LENGTH 32000
#define LOSEBG_WIDTH 200
#define LOSEBG_HEIGHT 160

#endif


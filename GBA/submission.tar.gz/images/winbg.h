/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=245x135 winbg winbg.jpg 
 * Time-stamp: Saturday 04/04/2020, 03:45:29
 * 
 * Image Information
 * -----------------
 * winbg.jpg 245@135
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WINBG_H
#define WINBG_H

extern const unsigned short winbg[33075];
#define WINBG_SIZE 66150
#define WINBG_LENGTH 33075
#define WINBG_WIDTH 245
#define WINBG_HEIGHT 135

#endif

